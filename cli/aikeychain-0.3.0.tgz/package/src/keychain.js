// Thin wrapper around the macOS `security` CLI.
// Lookup order matches scripts/akc (issue #91):
//   1. service="com.aieo.aikeychain" account="<KEY>"  (AI KeyChain GUI store)
//   2. service="<KEY>" with NO account               (manually-registered keys)
// Manual keys are looked up by service only because their `acct` attribute is
// not consistent ($USER or the service name) — pinning -a can grab a stale
// duplicate entry and return an invalid value.

import { execFile, spawn } from 'node:child_process';
import { promisify } from 'node:util';

const pExecFile = promisify(execFile);

export const KEY_NAME_PATTERN = /^[A-Za-z0-9_.-]+$/;

export const GUI_SERVICE = 'com.aieo.aikeychain';
// Manual entries are identified by env-var-shaped service names (e.g. GITHUB_TOKEN).
export const MANUAL_NAME_PATTERN = /^[A-Z][A-Z0-9_]*$/;

export class KeychainError extends Error {}

export function assertMacOS() {
  if (process.platform !== 'darwin') {
    throw new KeychainError(
      'aikeychain requires macOS: secrets are stored in the macOS Keychain via the `security` command.'
    );
  }
}

async function security(args) {
  try {
    const { stdout, stderr } = await pExecFile('security', args, {
      maxBuffer: 16 * 1024 * 1024,
    });
    return { ok: true, stdout, stderr };
  } catch (err) {
    return { ok: false, stdout: err.stdout ?? '', stderr: err.stderr ?? String(err) };
  }
}

function stripTrailingNewline(s) {
  return s.endsWith('\n') ? s.slice(0, -1) : s;
}

/** Resolve a key to its secret value, or null if not found. */
export async function resolveKey(name) {
  let r = await security(['find-generic-password', '-s', GUI_SERVICE, '-a', name, '-w']);
  if (r.ok) {
    const value = stripTrailingNewline(r.stdout);
    if (value) return value;
  }
  r = await security(['find-generic-password', '-s', name, '-w']);
  if (r.ok) {
    const value = stripTrailingNewline(r.stdout);
    if (value) return value;
  }
  return null;
}

/** Check where a key exists without reading its secret value. */
export async function keyExists(name) {
  const app = (await security(['find-generic-password', '-s', GUI_SERVICE, '-a', name])).ok;
  const manual = (await security(['find-generic-password', '-s', name])).ok;
  return { name, app, manual, exists: app || manual };
}

/** Redact hex-encoded secret material from text destined for errors/logs. */
export function redactSecrets(text) {
  return text.replace(/-X\s+[0-9a-fA-F]+/g, '-X <redacted>');
}

/** Run a command through `security -i`, which reads commands from stdin. */
function securityInteractive(commandLine) {
  return new Promise((resolve) => {
    const child = spawn('security', ['-i'], { stdio: ['pipe', 'pipe', 'pipe'] });
    let stdout = '';
    let stderr = '';
    child.stdout.on('data', (chunk) => (stdout += chunk));
    child.stderr.on('data', (chunk) => (stderr += chunk));
    child.on('error', (err) => resolve({ ok: false, stdout, stderr: String(err) }));
    child.on('close', (code) => resolve({ ok: code === 0, stdout, stderr }));
    child.stdin.write(`${commandLine}\n`);
    child.stdin.end();
  });
}

/**
 * Store a key. Defaults to the AI KeyChain GUI store so the entry shows up in
 * the app. `-U` updates in place to avoid acct-mismatched duplicates.
 *
 * The secret never appears in any process's argv (issue #94): the command is
 * fed to `security -i` via stdin, and the value is hex-encoded with -X so no
 * quoting of the interactive command line is needed.
 */
export async function setKey(name, value, { manual = false } = {}) {
  if (!name) throw new KeychainError('key name is required');
  if (!KEY_NAME_PATTERN.test(name)) {
    throw new KeychainError('key name must match [A-Za-z0-9_.-]+');
  }
  if (!value) throw new KeychainError('refusing to store an empty value');
  // Control characters would store fine but `find-generic-password -w` falls
  // back to hex output for them, breaking round-trips — reject up front.
  // eslint-disable-next-line no-control-regex
  if (/[\u0000-\u001f\u007f]/.test(value)) {
    throw new KeychainError('value must not contain control characters (newlines, tabs, NUL)');
  }
  const service = manual ? name : GUI_SERVICE;
  const hex = Buffer.from(value, 'utf8').toString('hex');
  const r = await securityInteractive(
    `add-generic-password -U -s "${service}" -a "${name}" -X ${hex}`
  );
  if (!r.ok) {
    // `security -i` stderr could in principle echo the command line (which
    // carries the hex value) — redact before it reaches CLI stderr / MCP.
    throw new KeychainError(`failed to save "${name}": ${redactSecrets(r.stderr.trim()) || 'unknown error'}`);
  }
  // Read-back verification against the exact target item: -U can report
  // success in odd keychain states while leaving a stale value behind.
  // (`find -w` prints hex for non-ASCII payloads, so accept that form too.)
  const readBack = await security(['find-generic-password', '-s', service, '-a', name, '-w']);
  const got = readBack.ok ? stripTrailingNewline(readBack.stdout) : null;
  if (got !== value && got?.toLowerCase() !== hex) {
    throw new KeychainError(
      `save reported success but reading "${name}" back returned a different value — check Keychain state`
    );
  }
  return { service, account: name };
}

/** Delete a key from the GUI store and/or the manual store. Returns which stores were deleted. */
export async function deleteKey(name, { app = true, manual = true } = {}) {
  const deleted = [];
  if (app) {
    const r = await security(['delete-generic-password', '-s', GUI_SERVICE, '-a', name]);
    if (r.ok) deleted.push('app');
  }
  if (manual) {
    const r = await security(['delete-generic-password', '-s', name]);
    if (r.ok) deleted.push('manual');
  }
  return deleted;
}

/** Parse `security dump-keychain` output into { service, account } records. */
export function parseDump(dump) {
  const records = [];
  for (const block of dump.split(/^keychain: /m)) {
    if (!/^class: "genp"/m.test(block)) continue;
    const svce = block.match(/"svce"<blob>="([^"\n]*)"/);
    const acct = block.match(/"acct"<blob>="([^"\n]*)"/);
    records.push({ service: svce ? svce[1] : null, account: acct ? acct[1] : null });
  }
  return records;
}

/**
 * List known keys (names only — secret values are never read).
 * Returns [{ name, sources: ['app'|'manual', ...] }] sorted by name.
 */
export async function listKeys() {
  const r = await security(['dump-keychain']);
  if (!r.ok) {
    throw new KeychainError(`failed to enumerate keychain items: ${r.stderr.trim()}`);
  }
  const keys = new Map();
  const add = (name, source) => {
    if (!keys.has(name)) keys.set(name, new Set());
    keys.get(name).add(source);
  };
  for (const { service, account } of parseDump(r.stdout)) {
    if (service === GUI_SERVICE && account) {
      add(account, 'app');
    } else if (service && service !== GUI_SERVICE && MANUAL_NAME_PATTERN.test(service)) {
      add(service, 'manual');
    }
  }
  return [...keys.entries()]
    .map(([name, sources]) => ({ name, sources: [...sources].sort() }))
    .sort((a, b) => a.name.localeCompare(b.name));
}

/**
 * Detect ambiguous duplicate entries: env-var-shaped service names that have
 * more than one generic-password item with distinct `acct` values. For such a
 * service, `security find-generic-password -s NAME -w` returns an unspecified
 * one of them — the root cause of issue #91 ("registered but invalid token").
 *
 * Secret values are never read; only the `acct` attribute (from dump-keychain)
 * is reported so the user can identify and remove the stale entry.
 *
 * Returns [{ service, accounts: [...] }] sorted by service, accounts sorted.
 */
export function findAmbiguousDuplicates(records) {
  const byService = new Map();
  for (const { service, account } of records) {
    if (!service || service === GUI_SERVICE) continue;
    if (!MANUAL_NAME_PATTERN.test(service)) continue;
    if (!byService.has(service)) byService.set(service, new Set());
    byService.get(service).add(account ?? '');
  }
  return [...byService.entries()]
    .filter(([, accts]) => accts.size > 1)
    .map(([service, accts]) => ({ service, accounts: [...accts].sort() }))
    .sort((a, b) => a.service.localeCompare(b.service));
}

/** Convenience wrapper around the live keychain dump (names/accts only). */
export async function listAmbiguousDuplicates() {
  const r = await security(['dump-keychain']);
  if (!r.ok) {
    throw new KeychainError(`failed to enumerate keychain items: ${r.stderr.trim()}`);
  }
  return findAmbiguousDuplicates(parseDump(r.stdout));
}

export function maskValue(value) {
  return `****** (${value.length} chars)`;
}
